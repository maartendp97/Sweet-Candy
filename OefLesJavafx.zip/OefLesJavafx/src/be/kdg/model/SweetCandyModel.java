package be.kdg.model;

public class SweetCandyModel {
}
