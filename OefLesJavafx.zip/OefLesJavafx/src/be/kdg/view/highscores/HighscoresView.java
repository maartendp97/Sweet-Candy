package be.kdg.view.highscores;

public class HighscoresView {
}
