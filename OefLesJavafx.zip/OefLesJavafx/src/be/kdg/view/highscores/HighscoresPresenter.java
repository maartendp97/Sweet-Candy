package be.kdg.view.highscores;

public class HighscoresPresenter {
}
