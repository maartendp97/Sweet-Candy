package be.kdg.view.Start;

import be.kdg.model.SweetCandyModel;
import javafx.event.ActionEvent;

public class StartPresenter {
    public void NewPlayerBtn(ActionEvent event){
        System.out.printf("welkom");
    }
}
