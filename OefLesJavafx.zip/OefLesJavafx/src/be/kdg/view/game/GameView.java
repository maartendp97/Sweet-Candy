package be.kdg.view.game;

public class GameView {
}
