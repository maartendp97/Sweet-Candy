package be.kdg.view.newGame;

public class NewGameView {
}
